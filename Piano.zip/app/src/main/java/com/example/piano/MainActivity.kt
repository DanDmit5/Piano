package com.example.piano

import android.media.MediaPlayer
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.widget.Button
import android.widget.ImageView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    // Медиаплеер для воспроизведения звуков
    private var mediaPlayer: MediaPlayer? = null
    // Список записанных нот
    private val recordedNotes = mutableListOf<NoteEvent>()
    // Флаг состояния записи
    private var isRecording = false
    // Время начала записи
    private var recordingStartTime = 0L
    // Обработчик для воспроизведения с задержкой
    private val handler = Handler(Looper.getMainLooper())

    // Класс для хранения информации о ноте и времени ее воспроизведения
    data class NoteEvent(
        val soundId: Int,       // ID звукового ресурса
        val timeOffset: Long     // Временное смещение от начала записи (мс)
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Сопоставление ImageView с соответствующими звуковыми файлами
        val imageViews = listOf(
            R.id.a3 to R.raw.a3,
            R.id.b3 to R.raw.b3,
            R.id.c3 to R.raw.c3,
            R.id.d3 to R.raw.d3,
            R.id.e3 to R.raw.e3,
            R.id.f3 to R.raw.f3,
            R.id.g3 to R.raw.g3
        )

        // Настройка обработчиков нажатия для клавиш пианино
        for ((imageId, soundId) in imageViews) {
            val imageView = findViewById<ImageView>(imageId)
            imageView.setOnClickListener {
                playSound(soundId)

                // Если идет запись, добавляем ноту в список
                if (isRecording) {
                    val timeOffset = System.currentTimeMillis() - recordingStartTime
                    recordedNotes.add(NoteEvent(soundId, timeOffset))
                }
            }
        }

        // Кнопка записи
        val recordButton = findViewById<ImageView>(R.id.record_button)
        recordButton.setOnClickListener {
            if (!isRecording) {
                startRecording()
                Toast.makeText(this, "Запись начата", Toast.LENGTH_SHORT).show()
            } else {
                stopRecording()
                Toast.makeText(this, "Запись остановлена. Нот: ${recordedNotes.size}", Toast.LENGTH_SHORT).show()
            }
        }

        // Кнопка воспроизведения
        val playButton = findViewById<ImageView>(R.id.play_button)
        playButton.setOnClickListener {
            if (recordedNotes.isNotEmpty()) {
                playRecording()
                Toast.makeText(this, "Воспроизведение записи", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this, "Нет записи для воспроизведения", Toast.LENGTH_SHORT).show()
            }
        }
    }

    // Воспроизведение звука по ID ресурса
    private fun playSound(soundId: Int) {
        mediaPlayer?.release()
        mediaPlayer = MediaPlayer.create(this, soundId)
        mediaPlayer?.start()
    }

    // Начало записи
    private fun startRecording() {
        recordedNotes.clear()
        isRecording = true
        recordingStartTime = System.currentTimeMillis()
    }

    // Остановка записи
    private fun stopRecording() {
        isRecording = false
    }

    // Воспроизведение записанной последовательности
    private fun playRecording() {
        if (recordedNotes.isEmpty()) return

        // Остановить текущее воспроизведение
        mediaPlayer?.release()

        // Воспроизвести каждую ноту с правильным временным смещением
        for (note in recordedNotes) {
            handler.postDelayed({
                playSound(note.soundId)
            }, note.timeOffset)
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        // Освободить ресурсы при уничтожении активности
        mediaPlayer?.release()
        mediaPlayer = null
        handler.removeCallbacksAndMessages(null)
    }
}

